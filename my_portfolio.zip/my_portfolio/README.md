# my_portfolio
 
I made my portfolio using Javascript,Html,Css and DOM so you can see there various functionalities I have put there and also animations I have given using Javascript.
You will see the section wise arrangement over there and also Intoduction page, Skills page, Contact page and also Resume.
